import logging
import unittest

import worker_function as wf

class TestLambda(unittest.TestCase):

   def test_lambda_valid(self):
      self.assertTrue(True)
      return
