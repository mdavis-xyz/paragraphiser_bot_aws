import nose
import json
import pprint as pp
import logging

def lambda_handler(event, context):
    #logger = logging.getLogger()
    #logger.setLevel(logging.INFO)
    print('lambda handler called for run_remote_tests')

    test_module = event['test_module'] # e.g. sample_test
    test_class = event['test_class']


    if event['mode'] == 'list':
        print('listing all test functions for this')

        test_package = __import__(test_module)

        all_methods = dir(getattr(test_package,test_class))

        test_methods = [fn for fn in all_methods if 'test_' in fn]

        print('functions for %s:%s: %s' % (test_module,test_class,str(test_methods)))

        return test_methods

    else:
        assert(event['mode'] == 'test')
        test_method = event['test_method'];
        print('Lambda handler about to test method: %s' % test_method)

        arg = test_module + '.py' + ':' + test_class + '.' + test_method
        print('Lambda handler running test for ' + arg)

        ret = nose.run(argv=['nosetests',arg])

        if ret:
            print('test passed: ' + arg)
        else:
            print('test failed : ' + arg)

        return ret
